#include <memory>  // For std::make_shared
#include "rclcpp/rclcpp.hpp"  // For rclcpp classes

class MotorSpeedController : public rclcpp::Node
{
public:
  MotorSpeedController() : Node("motor_speed_controller")
  {
    // Declare a parameter with default value 10
    this->declare_parameter<int>("motor_speed", 10);

    // Get and print the initial parameter value
    RCLCPP_INFO(this->get_logger(), "Motor controller started. Initial speed: %ld RPM",
                this->get_parameter("motor_speed").as_int());

    // Create ParameterEventHandler for this node
    param_event_handler_ = std::make_shared<rclcpp::ParameterEventHandler>(this);

    // Define callback when 'motor_speed' parameter changes
    auto callback = [this](const rclcpp::Parameter & param) {
      RCLCPP_INFO(this->get_logger(), "Motor speed updated to: %ld RPM", param.as_int());
    };

    // Register the callback and save the handle
    callback_handle_ = param_event_handler_->add_parameter_callback("motor_speed", callback);
  }

private:
  std::shared_ptr<rclcpp::ParameterEventHandler> param_event_handler_;
  std::shared_ptr<rclcpp::ParameterCallbackHandle> callback_handle_;
};

int main(int argc, char ** argv)
{
  rclcpp::init(argc, argv);
  rclcpp::spin(std::make_shared<MotorSpeedController>());
  rclcpp::shutdown();
  return 0;
}

