import time
import rclpy
from rclpy.action import ActionServer
from rclpy.node import Node

from food_delivery_interfaces.action import FoodDelivery  # Make sure this matches your .action path


class FoodDeliveryServer(Node):

    def __init__(self):
        super().__init__('food_delivery_server')
        self._action_server = ActionServer(
            self,
            FoodDelivery,
            'deliver_food',
            self.execute_callback)

    def execute_callback(self, goal_handle):
        self.get_logger().info(f"Received order: {goal_handle.request.food_item} to {goal_handle.request.delivery_address}")
        
        feedback_msg = FoodDelivery.Feedback()
        progress_steps = [
            "Order received",
            "Food is being prepared",
            "Picked up by delivery agent",
            "En route to destination",
            "Almost there"
        ]

        for step in progress_steps:
            feedback_msg.progress = step
            goal_handle.publish_feedback(feedback_msg)
            self.get_logger().info(f'Feedback: {step}')
            time.sleep(1.5)

        goal_handle.succeed()

        result = FoodDelivery.Result()
        result.status = f"{goal_handle.request.food_item} delivered to {goal_handle.request.delivery_address} successfully!"
        return result


def main(args=None):
    rclpy.init(args=args)
    node = FoodDeliveryServer()
    rclpy.spin(node)


if __name__ == '__main__':
    main()

