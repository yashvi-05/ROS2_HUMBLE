# ROS 2 Python node to:
# - Track robot and goal position
# - Calculate distance
# - Estimate time based on assumed travel time per meter
# - Follow red path (from planner) and check deviation
# - Print result on reaching goal

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import PoseWithCovarianceStamped, PoseStamped
from nav2_msgs.action import NavigateToPose
from action_msgs.msg import GoalStatusArray
from nav_msgs.msg import Path
import math
import time

class GoalTimeEstimator(Node):
    def __init__(self):
        super().__init__('goal_time_estimator')

        self.goal_x = None
        self.goal_y = None
        self.robot_x = None
        self.robot_y = None

        self.goal_active = False
        self.prev_status = None

        self.start_time = None
        self.assumed_time_per_meter = 0.1  # seconds per meter

        self.path_received = False
        self.path_poses = []

        # Subscribers
        self.create_subscription(PoseWithCovarianceStamped, '/amcl_pose', self.pose_callback, 10)
        self.create_subscription(PoseStamped, '/goal_pose', self.goal_callback, 10)
        self.create_subscription(GoalStatusArray, '/navigate_to_pose/_action/status', self.status_callback, 10)
        self.create_subscription(Path, '/plan', self.path_callback, 10)

        self.create_timer(0.5, self.timer_callback)

    def goal_callback(self, msg):
        self.goal_x = msg.pose.position.x
        self.goal_y = msg.pose.position.y
        self.goal_active = True
        self.start_time = time.time()
        print(f"\n New Goal: x = {self.goal_x:.2f}, y = {self.goal_y:.2f}", flush=True)

    def pose_callback(self, msg):
        self.robot_x = msg.pose.pose.position.x
        self.robot_y = msg.pose.pose.position.y

    def status_callback(self, msg):
        if not msg.status_list:
            return
        latest_status = msg.status_list[-1].status
        if latest_status != self.prev_status:
            self.prev_status = latest_status

            if latest_status == 2:
                print(" Navigating to goal...", flush=True)

            elif latest_status == 4:
                self.goal_active = False
                print(" Goal Reached!", flush=True)
                print(f"Final Robot Position: x = {self.robot_x:.2f}, y = {self.robot_y:.2f}", flush=True)

                if self.goal_x is not None and self.goal_y is not None:
                    print(f" Goal Position: x = {self.goal_x:.2f}, y = {self.goal_y:.2f}", flush=True)
                else:
                    print(" Goal position not recorded.", flush=True)

                if self.start_time:
                    actual_time = time.time() - self.start_time
                    print(f"Actual Time Taken: {actual_time:.2f} seconds", flush=True)

    def path_callback(self, msg):
        self.path_received = True
        self.path_poses = msg.poses

        if len(self.path_poses) > 0:
            start = self.path_poses[0].pose.position
            end = self.path_poses[-1].pose.position
            dx = end.x - start.x
            dy = end.y - start.y
            path_distance = math.sqrt(dx**2 + dy**2)
            estimated_time = path_distance / self.assumed_time_per_meter
            print(f"\n  path received.")
            print(f"Start : x = {start.x:.2f}, y = {start.y:.2f}", flush=True)
            print(f"Goal  : x = {end.x:.2f}, y = {end.y:.2f}", flush=True)
            print(f"Path Distance: {path_distance:.2f} m", flush=True)
            print(f"Estimated Travel Time: {estimated_time:.2f} seconds\n", flush=True)

    def get_closest_path_point(self):
        min_dist = float('inf')
        closest = None
        for pose in self.path_poses:
            x = pose.pose.position.x
            y = pose.pose.position.y
            dist = math.sqrt((x - self.robot_x)**2 + (y - self.robot_y)**2)
            if dist < min_dist:
                min_dist = dist
                closest = pose.pose.position
        return closest

    def timer_callback(self):
        if self.goal_active and self.robot_x is not None and self.goal_x is not None:
            dx = self.goal_x - self.robot_x
            dy = self.goal_y - self.robot_y
            distance = math.sqrt(dx**2 + dy**2)
            eta = distance / self.assumed_time_per_meter
            print(f"\n Robot: x = {self.robot_x:.2f}, y = {self.robot_y:.2f}", flush=True)
            print(f" Goal : x = {self.goal_x:.2f}, y = {self.goal_y:.2f}", flush=True)
            print(f" Distance to Goal: {distance:.2f} m", flush=True)
            print(f"Estimated Time to Reach Goal: {eta:.2f} sec (based on {self.assumed_time_per_meter:.2f} sec/m)", flush=True)

            if self.path_received:
                closest = self.get_closest_path_point()
                if closest:
                    deviation = math.sqrt((self.robot_x - closest.x)**2 + (self.robot_y - closest.y)**2)
                    print(f" Closest Path Point: x = {closest.x:.2f}, y = {closest.y:.2f}", flush=True)
                    print(f" Deviation from Path: {deviation:.2f} m", flush=True)
                    if deviation > 0.5:
                        print(" WARNING: Robot is deviating from the planned path!", flush=True)


def main(args=None):
    rclpy.init(args=args)
    node = GoalTimeEstimator()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

