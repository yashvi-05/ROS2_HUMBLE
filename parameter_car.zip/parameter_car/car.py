class Car:
    def __init__(self, brand, color):
        self.brand = brand
        self.color = color

# Create object
my_car = Car("Toyota", "Red")

# Access the object's parameters
print(my_car.brand)  # Output: Toyota
print(my_car.color)  # Output: Red

