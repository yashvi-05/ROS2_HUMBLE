// english_greeting.hpp
#pragma once

#include "greeting_plugin/greeting_interface.hpp"
#include <pluginlib/class_list_macros.hpp>

namespace greeting_plugin
{
  class EnglishGreeting : public GreetingInterface
  {
  public:
    std::string say_hello() override
    {
      return "Hello from English Greeting!";
    }
  };
}

// Register the plugin
PLUGINLIB_EXPORT_CLASS(greeting_plugin::EnglishGreeting, greeting_plugin::GreetingInterface)

