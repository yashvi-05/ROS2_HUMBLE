// greeting_interface.hpp
#pragma once

#include <string>

namespace greeting_plugin
{
  class GreetingInterface
  {
  public:
    virtual ~GreetingInterface() = default;
    virtual std::string say_hello() = 0;
  };
}

