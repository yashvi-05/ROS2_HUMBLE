// spanish_greeting.hpp
#pragma once

#include "greeting_plugin/greeting_interface.hpp"
#include <pluginlib/class_list_macros.hpp>

namespace greeting_plugin
{
  class SpanishGreeting : public GreetingInterface
  {
  public:
    std::string say_hello() override
    {
      return "¡Hola desde el saludo en Español!";
    }
  };
}

// Register the plugin
PLUGINLIB_EXPORT_CLASS(greeting_plugin::SpanishGreeting, greeting_plugin::GreetingInterface)

