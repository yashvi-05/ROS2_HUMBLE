// english_greeting.cpp
#include "greeting_plugin/english_greeting.hpp"

