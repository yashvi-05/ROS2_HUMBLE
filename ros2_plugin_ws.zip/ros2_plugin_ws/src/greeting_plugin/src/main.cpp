// main.cpp
#include <pluginlib/class_loader.hpp>
#include "greeting_plugin/greeting_interface.hpp"
#include <memory>
#include <iostream>

int main()
{
  pluginlib::ClassLoader<greeting_plugin::GreetingInterface> loader("greeting_plugin", "greeting_plugin::GreetingInterface");

  try
  {
    auto english = loader.createSharedInstance("greeting_plugin/EnglishGreeting");
    std::cout << english->say_hello() << std::endl;

    auto spanish = loader.createSharedInstance("greeting_plugin/SpanishGreeting");
    std::cout << spanish->say_hello() << std::endl;
  }
  catch (const pluginlib::PluginlibException &ex)
  {
    std::cout << "The plugin failed to load for some reason. Error: " << ex.what() << std::endl;
  }

  return 0;
}

