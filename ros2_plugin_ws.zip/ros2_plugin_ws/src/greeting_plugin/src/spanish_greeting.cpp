// spanish_greeting.cpp
#include "greeting_plugin/spanish_greeting.hpp"

