#!/usr/bin/env python3

import rclpy
from rclpy.node import Node

from geometry_msgs.msg import TransformStamped
from tf2_ros.static_transform_broadcaster import StaticTransformBroadcaster


class FixedTFBroadcaster(Node):

    def __init__(self):
        super().__init__('fixed_tf2_broadcaster')

        # Create static broadcaster
        self.broadcaster = StaticTransformBroadcaster(self)

        # Create the transform message
        static_transform = TransformStamped()
        static_transform.header.stamp = self.get_clock().now().to_msg()
        static_transform.header.frame_id = 'world'
        static_transform.child_frame_id = 'robot_1'

        static_transform.transform.translation.x = 0.0
        static_transform.transform.translation.y = 2.0
        static_transform.transform.translation.z = 0.0

        static_transform.transform.rotation.x = 0.0
        static_transform.transform.rotation.y = 0.0
        static_transform.transform.rotation.z = 0.0
        static_transform.transform.rotation.w = 1.0

        # Send the static transform once
        self.broadcaster.sendTransform(static_transform)
        self.get_logger().info('Published static transform from world to robot_1')


def main():
    rclpy.init()
    node = FixedTFBroadcaster()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

