from setuptools import setup

package_name = 'transforms_wiki'

setup(
    name=package_name,
    version='0.0.0',
    packages=[package_name],
    data_files=[
        ('share/' + package_name, ['package.xml']),
    ],
    install_requires=['setuptools'],
    zip_safe=True,
    maintainer='luqman',
    maintainer_email='luqman@todo.todo',
    description='TF2 dynamic and fixed broadcasters in ROS 2',
    license='MIT',
    tests_require=['pytest'],
    entry_points={
        'console_scripts': [
            'fixed_tf2_broadcaster = transforms_wiki.fixed_tf2_broadcaster:main',
            'dynamic_tf2_broadcaster = transforms_wiki.dynamic_tf2_broadcaster:main',
        ],
    },
)

