#!/usr/bin/env python3
import rclpy
from rclpy.node import Node
from tf2_ros import TransformBroadcaster
from geometry_msgs.msg import TransformStamped
import math

class DynamicTF2Broadcaster(Node):

    def __init__(self):
        super().__init__('dynamic_tf2_broadcaster_2')
        self.br = TransformBroadcaster(self)
        self.t = TransformStamped()
        self.t.header.frame_id = 'robot_2'
        self.t.child_frame_id = 'wheel'

        self.timer = self.create_timer(0.1, self.broadcast_callback)  # 10 Hz

    def broadcast_callback(self):
        now = self.get_clock().now().to_msg()
        x = self.get_clock().now().seconds_nanoseconds()[0] * math.pi

        self.t.header.stamp = now
        self.t.transform.translation.x = math.sin(x)
        self.t.transform.translation.y = math.cos(x)
        self.t.transform.translation.z = 0.0
        self.t.transform.rotation.x = 0.0
        self.t.transform.rotation.y = 0.0
        self.t.transform.rotation.z = 0.0
        self.t.transform.rotation.w = 1.0

        self.br.sendTransform(self.t)

def main():
    rclpy.init()
    node = DynamicTF2Broadcaster()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()

